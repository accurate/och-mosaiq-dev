<?php


/*
function slider_get_post_content_callback() {

            // You have to return data as json
			wp_send_json([
                'actor_id' => $actor_id,
                'actor_fname' => $actor_fname,
                'actor_lname' => $actor_lname,
                'actor_age' => $actor_age,
                'actor_height' => $actor_height,
                'actor_bilingual' => $actor_bilingual,
                'actor_disciplines' => $actor_disciplines,
                'actor_selfie' => $actor_selfie,
                'actor_photoset' => $actor_photoset,
                'actor_video' => $actor_video_url_final,
                'actor_featuredimage' => $actor_featuredimage
			]);

            //wp_reset_postdata();
        endwhile; 
    endif;  

}

add_action( 'wp_ajax_slider_get_post_content', 'slider_get_post_content_callback' );
// If you want not logged in users to be allowed to use this function as well, register it again with this function:
add_action( 'wp_ajax_nopriv_slider_get_post_content', 'slider_get_post_content_callback' );


*/

?>